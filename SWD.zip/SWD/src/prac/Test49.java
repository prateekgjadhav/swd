package prac;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test49
{
	public static void main(String[] args) throws Exception 
	{
		//Open file1 with read mode
		File f1=new File("E:\\batch226\\testdata.txt");
		FileReader fr=new FileReader(f1);
		BufferedReader br=new BufferedReader(fr);
		//Open file2 with write mode
		File f2=new File("E:\\batch226\\result.txt");
		FileWriter fw=new FileWriter(f2);
		BufferedWriter bw=new BufferedWriter(fw);
		//Data driven testing
		String x=br.readLine(); //read first line
		while(x!=null)
		{
			WebDriver driver=new FirefoxDriver();
			driver.get("http://www.google.co.in");
			Thread.sleep(5000);
			driver.findElement(By.name("q")).sendKeys(x);
			driver.findElement(By.name("btnG")).click();
			Thread.sleep(5000);
			if(driver.getTitle().contains(x))
			{
				bw.write("Test passed");
				bw.newLine();
			}
			else
			{
				bw.write("Test failed");
				bw.newLine();
			}
			driver.close();
			x=br.readLine(); //read next line in file
		}
		br.close();
		bw.close();
		fr.close();
		fw.close();
	}
}







