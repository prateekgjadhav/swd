package prac;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test03 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.geckodriver.firefox","C:\\Desktop\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.google.co.in");
		Thread.sleep(5000);
		driver.manage().window().maximize();
		int w=driver.manage().window().getSize()
				                         .getWidth();
		int h=driver.manage().window().getSize()
				                         .getHeight();
		System.out.println(w+" "+h);
		int x=driver.manage().window().getPosition()
				                             .getX();
		int y=driver.manage().window().getPosition()
				                            .getY();
		System.out.println(x+" "+y);
		Dimension d=new Dimension(400,200);
		driver.manage().window().setSize(d);
		Thread.sleep(5000);
		Point p=new Point(100,200);
		driver.manage().window().setPosition(p);
	}
}






