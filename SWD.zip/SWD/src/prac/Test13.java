package prac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Test13
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("http://jqueryui.com/droppable/");
		Thread.sleep(5000);
		driver.switchTo().frame(0);//have one frame 
		Actions a=new Actions(driver);
		WebElement e1=driver.findElement(
				               By.id("draggable"));
		WebElement e2=driver.findElement(
				               By.id("droppable"));
		a.dragAndDropBy(e1,300,300).build().perform();
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		//driver.close();

	}

}




