package prac;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
public class Test40 
{
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		//Get data from keyboard
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter mobile number");          
		String mbno=sc.nextLine();
		System.out.println("Enter mobile number criteria");          
		String mc=sc.nextLine();
		System.out.println("Enter password");          
		String p=sc.nextLine();
		System.out.println("Enter password criteria");          
		String pc=sc.nextLine();
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://site21.way2sms.com/content/index.html");
		Thread.sleep(5000);
		//Fill fields and click sign-in
		driver.findElement(By.name("username")).sendKeys(mbno);
		driver.findElement(By.name("password")).sendKeys(p);
		driver.findElement(By.id("loginBTN")).click();
		Thread.sleep(5000);
		//Testing
		if(mbno.length()<10 && ExpectedConditions.alertIsPresent()!=null)
		{
			System.out.println("Test passed when mobile number less than 10 digits");
		}
		else if(mc.equals("invalid") && driver.findElement(By.xpath
			("//span[starts-with(text(),'Oops, looks')]")).isDisplayed())
		{
			System.out.println("Test passed when mobile number is invalid");
		}
		else if(mc.equals("valid") && pc.equals("invalid") && driver.findElement(By.xpath("//*[starts-with(text(),'Forgot Password?')]"))
		                                  .isDisplayed())
		{
			System.out.println("Test passed when password is invalid");
		}
		else if(mc.equals("valid") && pc.equals("valid") && driver.findElement(By.xpath("//*[@value='Skip' or @value='Send Free SMS']")).isDisplayed())
		{
			System.out.println("Test passed when all are valid");     
		}
		else
		{
			System.out.println("Test failed");
			File ss=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			File df=new File("E:\\batch226\\bugss.png");
			FileUtils.copyFile(ss,df); //apache class in jdk
		}
		//Close site
		driver.quit();
	}
}







