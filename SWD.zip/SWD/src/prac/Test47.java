package prac;
import java.util.Scanner;
public class Test47
{
	public static void main(String[] args) 
	{
		//Get series limit from keyboard                    
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter limit");
		int l=Integer.parseInt(sc.nextLine());  
		int x=0;
		int y=1;
		int z=x+y;
		System.out.print(x+" "+y);
		while(z<l)
		{
			System.out.print(" "+z);
			x=y;
			y=z;
			z=x+y;
		}
	}

}
