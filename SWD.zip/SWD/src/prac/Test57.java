package prac;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class Test57 
{
	public static void main(String[] args) throws Exception 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter order number");
		String x=sc.nextLine();
		System.out.println("Enter customer name");
		String y=sc.nextLine();
		//connect to DB
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("Jdbc:Odbc:kalam");
		//Perform update
		Statement st=con.createStatement();
		st.executeUpdate("update orders set customer_name='"+y+"' where order_number="+x);
		//select updated data into resultset
		ResultSet rs=st.executeQuery("select customer_name from orders where order_number="+x);
		rs.next(); //go to first row in resultset
		if(rs.getString(1).equals(y))
		{
			System.out.println("Updated successfully");
		}
		else
		{
			System.out.println("Wrong updation");
		}
		//Disconnect from DB
		con.close();	
	}
}






