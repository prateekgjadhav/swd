package prac;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
public class Test11 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		Thread.sleep(5000);
		//Click create account link
		driver.findElement(By.partialLinkText("Create")).click();
		Thread.sleep(5000);
		//Fill fields
		driver.findElement(By.name("FirstName")).sendKeys("subbu");
		driver.findElement(By.name("LastName")).sendKeys("rao");
		driver.findElement(By.name("GmailAddress")).sendKeys("subbujessi143");      
		driver.findElement(By.name("Passwd")).sendKeys("jessyismylife");
		driver.findElement(By.name("PasswdAgain")).sendKeys("jessyismylife");
		Thread.sleep(5000);
		Actions a=new Actions(driver);
		a.sendKeys(Keys.TAB,Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys("jul",Keys.ENTER).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.name("BirthDay")).sendKeys("18");
		driver.findElement(By.name("BirthYear")).sendKeys("1996");
		Thread.sleep(5000);
		a.sendKeys(Keys.TAB,Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys("m",Keys.ENTER).build().perform();
		Thread.sleep(5000);
		a.sendKeys(Keys.TAB,Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.name("RecoveryPhoneNumber")).sendKeys("9999999999");
		driver.findElement(By.name("RecoveryEmailAddress")).sendKeys("jessysubbu143@gmail.com");
		Thread.sleep(5000);
		a.sendKeys(Keys.TAB,Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys("i",Keys.DOWN,Keys.ENTER).build().perform();
		Thread.sleep(5000);
		driver.findElement(By.name("submitbutton")).click();
		Thread.sleep(5000);
		//Close site
		driver.close();
	}
}




