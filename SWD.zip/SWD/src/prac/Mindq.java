package prac;
public class Mindq 
{
	static int a;
	static int b;
	static void display()
	{
		System.out.println(a+" "+b);
	}
}




