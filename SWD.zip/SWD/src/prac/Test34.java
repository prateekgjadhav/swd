package prac;
public abstract class Test34 
{
	int x=10; //data member
	int y=20; //data member
	public int add()
	{
		int z;
		z=x+y;
		return(z);
	}
	public abstract int substract(); //declaration      
	public abstract int multiply(); //declaration
	public int divison()
	{
		int z;
		z=x/y;
		return(z);
	}
}




