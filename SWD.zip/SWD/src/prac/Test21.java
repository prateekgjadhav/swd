package prac;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Test21
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site for home page loading
		WebDriver driver=new FirefoxDriver();
		driver.get("http://demos.telerik.com/aspnet-ajax/ajax/examples/loadingpanel/explicitshowhide/defaultcs.aspx");
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS); 
		//Get the text before performing an ajax call
		String t1=driver.findElement(By.xpath("//div[@class='RadAjaxPanel']/span")).getText();
		System.out.println(t1);
		//Click on the date for data loading
		driver.findElement(By.linkText("22")).click();
		WebDriverWait w=new WebDriverWait(driver,50);
		w.until(ExpectedConditions.invisibilityOfElementLocated(By.className("raDiv")));
		//Get the text after ajax call
		String t2=driver.findElement(By.xpath("//div[@class='RadAjaxPanel']/span")).getText();   
		System.out.println(t2);
		//Close site
		driver.close();
	}
}









