package prac;
public class Test33 
{
	public static void main(String[] args) 
	{
		Test31 obj1=new Test32();
		Test32 obj2=new Test32();
		int r1=obj1.substract(); //method calling
		int r2=obj2.substract(); //method calling
		System.out.println(r1+" "+r2);
	}
}


