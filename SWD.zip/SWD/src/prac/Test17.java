package prac;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test17 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://semantic-ui.com/collections/form.html");
		Thread.sleep(15000);
		WebElement e=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[16]/div"));
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",e);
		

	}

}





