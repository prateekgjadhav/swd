package prac;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test02 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		System.setProperty("webdriver.geckodriver.firefox","C:\\Desktop\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://site24.way2sms.com/entry.jsp");
		Thread.sleep(5000);//java
		//Close additional browser windows
		ArrayList x=new ArrayList(driver.getWindowHandles());
		for(int i=1;i<x.size();i++)
		{
			driver.switchTo().window((String)x.get(i));
			driver.close();
		}
		driver.switchTo().window((String)x.get(0));
		//Do login
		driver.findElement(By.name("username")).sendKeys("9700665505");
		driver.findElement(By.name("password")).sendKeys("111111"); 
		driver.findElement(By.id("loginBTN")).click();
		Thread.sleep(5000);
		//Click send free sms
		driver.findElement(By.xpath("/html/body/div[2]/div/form/div[2]/div[1]/input")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[7]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(5000);
		//Switch to frame
		driver.switchTo().frame("frame");
		driver.findElement(By.name("mobile")).sendKeys("9885164878");
		driver.findElement(By.name("message")).sendKeys("switch-off mobile in class room");
		driver.findElement(By.name("Send")).click();
		Thread.sleep(5000);
		//Close additional browser windows
		ArrayList y=new ArrayList(driver.getWindowHandles());
		for(int i=1;i<y.size();i++)
		{
			driver.switchTo().window((String)y.get(i));
			driver.close();
		}
		driver.switchTo().window((String)y.get(0));
		driver.switchTo().frame("frame");
		String m=driver.findElement(By.xpath("/html/body/form/div[3]/div/p/span")).getText();
		System.out.println(m);
		//Back to page
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("/html/body/div[5]/div/ul/li[7]/i")).click();
		Thread.sleep(5000);
		//Close additional browser windows
		ArrayList z=new ArrayList(driver.getWindowHandles());
		for(int i=1;i<z.size();i++)
		{
			driver.switchTo().window((String)z.get(i));
			driver.close();
		}
		driver.switchTo().window((String)z.get(0));
		//Close site
		driver.close();
	}
}




