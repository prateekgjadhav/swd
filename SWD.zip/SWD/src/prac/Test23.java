package prac;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
public class Test23 
{
	public static void main(String[] args) throws IOException, InterruptedException, AWTException
	{
		//Launch notepad
		Runtime.getRuntime().exec("notepad.exe");
		Thread.sleep(5000);
		//Put text in clip-board
		StringSelection x=
		  new StringSelection("Amma nanna one testing job");
		Toolkit.getDefaultToolkit().getSystemClipboard()
		                     .setContents(x, null);
		//Send clip-board data to note-pad
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(5000);
		//Close note-pad without save
		r.keyPress(KeyEvent.VK_ALT);
		r.keyPress(KeyEvent.VK_F4);
		r.keyRelease(KeyEvent.VK_F4);
		r.keyRelease(KeyEvent.VK_ALT);
		Thread.sleep(5000);
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(5000);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER); 
	}
}





