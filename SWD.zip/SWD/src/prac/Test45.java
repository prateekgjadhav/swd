package prac;
import java.util.List;
import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test45 
{
	public static void main(String[] args) throws InterruptedException 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter userid");
		String uid=sc.nextLine();
		System.out.println("Enter password");               
		String pwd=sc.nextLine();
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.name("Email")).sendKeys(uid);
		driver.findElement(By.id("next")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Passwd")).sendKeys(pwd);
		driver.findElement(By.id("signIn")).click();
		Thread.sleep(5000);
		//Count all mails in mailbox
		int enoam=0;
		do
		{
			Thread.sleep(5000);
			WebElement mbox=driver.findElement(By.xpath("(//*[@role='tabpanel'])[1]/div[2]/div/table/tbody"));
			List<WebElement> rows=mbox.findElements(By.tagName("tr"));
			int nomp=rows.size();
			enoam=enoam+nomp;
			//goto Next page
			try{
			if(driver.findElement(By.xpath("//*[@data-tooltip='Older']")).getAttribute("aria-disabled").equals("true"))
				{
					break; //terminate from infinite loop
				}
			}
			catch(Exception e)
			{
				driver.findElement(By.xpath("//*[@data-tooltip='Older']")).click();
				Thread.sleep(5000);
			}
		}while(2>1); //infinite loop
		System.out.println(enoam);
		//Get visible count of all mails
		String msg=driver.findElement(By.xpath("//*[@data-tooltip='Newer']/preceding::b[1]")).getText();
		msg=msg.replace(",","");
		int anoam=Integer.parseInt(msg);
		System.out.println(anoam);
		if(enoam==anoam)
		{
			System.out.println("Mails count test passed");
		}
		else
		{
			System.out.println("Mails count test failed");
		}
		//Do logout
		driver.findElement(By.xpath("//*[starts-with(@title,'Google Account:')]/span")).click();
		Thread.sleep(5000);
		driver.findElement(By.linkText("Sign out")).click();
		Thread.sleep(5000);		
		driver.close();
	}
}







