package prac;
import java.util.ArrayList;
import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test48 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Get multiple data from keyboard into array
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter data limit");
		int n=Integer.parseInt(sc.nextLine());
		ArrayList<String> x=new ArrayList<String>();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter a value");
			x.add(sc.nextLine());
		}
		//Data driven testing
		for(int i=0;i<n;i++)
		{
			WebDriver driver=new FirefoxDriver();
			driver.get("http://www.google.co.in");
			Thread.sleep(5000);
			driver.findElement(By.name("q")).sendKeys(x.get(i));
			driver.findElement(By.name("btnG")).click();
			Thread.sleep(5000);
			if(driver.getTitle().contains(x.get(i)))
			{
				System.out.println("Test passed");
			}
			else
			{
				System.out.println("Test failed");
			}
			driver.close();
		}
		
		
		

	}

}
