package prac;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test38 
{
	public static void main(String[] args) throws InterruptedException 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a word to search");
		String x=sc.nextLine();
		//Launch google site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.google.co.in");
		driver.manage().timeouts()
		      .implicitlyWait(10,TimeUnit.SECONDS);
		//Enter a word to search
		driver.findElement(By.name("q"))
		                        .sendKeys(x); //parameterization       
		driver.findElement(By.name("btnG")).click();
		Thread.sleep(5000);   
		//check title contains searched word
		if(driver.getTitle().contains(x))
		{
			System.out.println("Test passed");
		}
		else	
		{
			System.out.println("Test failed");
		}
		//close site
		driver.close();
	}

}






