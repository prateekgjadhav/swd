package prac;
public class Test32 implements Test31
{
	int a; //data member
	public Test32() //constructor
	{
		a=100;
	}
	public int add() //method implementation
	{
		int z;
		z=x+y;
		return(z);
	}
	public int substract() //method implementation
	{
		int z;
		z=x-y;
		return(z);
	}
	public int multiply()//method implementation
	{
		int z;
		z=x*y;
		return(z);
	}
	public int divison()//method implementation
	{
		int z;
		z=x/y;
		return(z);
	}
}

