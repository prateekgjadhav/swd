package prac;
public interface Test31 
{
	int x=10; //data member
	int y=20; //data member
	public int add(); //Method declaration
	public int substract(); //Method declaration
	public int multiply(); //Method declaration
	public int divison(); //Method declaration
}




