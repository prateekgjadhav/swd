package prac;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test50 
{
	public static void main(String[] args) throws Exception
	{
		//Open file1 with read mode
		File f1=new File("E:\\batch226\\testdata.txt");
		FileReader fr=new FileReader(f1);
		BufferedReader br=new BufferedReader(fr);
		//Open file2 with write mode
		File f2=new File("E:\\batch226\\result.txt");
		FileWriter fw=new FileWriter(f2);
		BufferedWriter bw=new BufferedWriter(fw);
		//Data driven testing
		String x=br.readLine(); //read first line
		while(x!=null)
		{
			String y[]=x.split(",");
			//Launch site
			WebDriver driver=new FirefoxDriver();
			driver.get("http://www.gmail.com");
			Thread.sleep(5000);
			//Userid testing
			driver.findElement(By.name("Email")).sendKeys(y[0]);
			driver.findElement(By.id("next")).click();
			Thread.sleep(5000);
			if(y[1].equals("valid") &&
					driver.findElement(By.name("Passwd"))
					.isDisplayed())
			{
				bw.write("Userid test passed for valid data");
				//Password testing
				driver.findElement(By.name("Passwd"))
				                    		.sendKeys(y[2]);
				driver.findElement(By.id("signIn")).click();
				Thread.sleep(5000);
				if(y[3].equals("valid") && 
				   driver.findElement(By.xpath(
					"//*[text()='COMPOSE']")).isDisplayed())
				{
					bw.write(", password test was passed for valid data");
					bw.newLine();
				}
				else if(y[3].equals("invalid") &&
						driver.findElement(By.id(
						"errormsg_0_Passwd")).isDisplayed())
				{
					bw.write(", Password test was passed for invalid data");
					bw.newLine();
				}
				else
				{
					bw.write(", Password test failed");
					bw.newLine();
				}
			}
			else if(y[1].equals("invalid") &&
					driver.findElement(By.id(
					"errormsg_0_Email")).isDisplayed())
			{
				bw.write("Userid test was passed for invalid data");
				bw.newLine();
			}
			else
			{
				bw.write("Userid test was failed");
				bw.newLine();
			}
			driver.close();
			x=br.readLine(); //take next line
		}
		br.close();
		bw.close();
		fr.close();
		fw.close();	
	}
}
	
	
	
	
	
