package prac;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test41 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.mercurytravels.co.in");
		Thread.sleep(5000);
		//Get all input tag elements in page
		List<WebElement> l=driver.findElements(
				                 By.tagName("input"));
		int notb=0; //text boxes
		int nob=0; //buttons
		int nocb=0; //check boxes
		int nop=0; //password boxes
		int norb=0; //radio buttons
		int nodt=0; //datetime
		int nosb=0; //search
		int noemail=0; //email
		int notel=0; //tel
		int noh=0; //hidden
		int others=0;
		for(int i=0;i<l.size();i++)
		{
			String x=l.get(i).getAttribute("type");
			switch(x)
			{
			case "text":
				notb=notb+1;
				break;
			case "radio":
				norb=norb+1;
				break;
			case "checkbox":
				nocb=nocb+1;
				break;
			case "button":
				nob=nob+1;
				break;
			case "password":
				nop=nop+1;
				break;
			case "datetime":
				nodt=nodt+1;
				break;
			case "email":
				noemail=noemail+1;
				break;
			case "search":
				nosb=nosb+1;
				break;
			case "tel":
				notel=notel+1;
				break;
			case "hidden":
				noh=noh+1;
				break;
			default:
				others=others+1;
				break;
			}
		}
		//close site
		driver.close();
		System.out.println("No: of text boxes "+notb);
		System.out.println("No: of check boxes "+nocb);
		System.out.println("No: of radio buttons "+norb);
		System.out.println("No: of password boxes "+nop);
		System.out.println("No: of buttons "+nob);
		System.out.println("No: of date and time boxes "+nodt);
		System.out.println("No: of email boxes "+noemail);
		System.out.println("No: of search boxes "+nosb);
		System.out.println("No: of tel boxes "+notel);
		System.out.println("No: of hidden boxes "+noh);
		System.out.println("No: of others "+others);
	}
}
