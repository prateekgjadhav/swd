package prac;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test39 
{
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter userid");
		String u=sc.nextLine();
		System.out.println("Enter criteria");               
		String uc=sc.nextLine();
		String p="";
		String pc="";
		if(uc.equals("valid"))
		{
			System.out.print("Enter password");
			p=sc.nextLine();
			System.out.print("Enter password criteria");
			pc=sc.nextLine();			
		}
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		Thread.sleep(5000);
		//fill user-id and click next
		driver.findElement(By.name("Email")).sendKeys(u);
		driver.findElement(By.id("next")).click();
		Thread.sleep(5000);    
		//User-id testing
		if(uc.equals("valid") && driver.findElement(By.name("Passwd")).isDisplayed())      
		{
			System.out.print("Test passed for valid userid");
			//Password testing
			driver.findElement(By.name("Passwd")).sendKeys(p);
			driver.findElement(By.id("signIn")).click();
			Thread.sleep(5000);
			if(pc.equals("valid") && driver.findElement(By.xpath("//*[text()='COMPOSE']")).isDisplayed())
			{
				System.out.println("Test passed when password is valid");
			}
			else if(pc.equals("invalid") && driver.findElement(By.id("errormsg_0_Passwd")).isDisplayed())
			{
				System.out.println("Test passed when password is invalid");
			}
			else
			{
				System.out.println("Password test was failed");
				File ss=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				File df=new File("E:\\batch226\\pbugss.png");
				FileUtils.copyFile(ss,df); 
			}
		}
		else if(uc.equals("invalid") && driver.findElement(By.id("errormsg_0_Email")).isDisplayed())
		{
		 System.out.println("Test passed for invalid userid");	
		}
		else
		{
			System.out.println("Userid Test failed");
			File ss=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			File df=new File("E:\\batch226\\ubugss.png");
			FileUtils.copyFile(ss,df); 
		}
		//Close site
		driver.close();
	}
}












