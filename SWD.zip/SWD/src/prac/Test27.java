package prac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test27 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","E:\\batch225\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.imacros.net/Automate/Frames");
		Thread.sleep(5000);
		driver.switchTo().frame("top");
		String x=driver.findElement(By.xpath("html/body/header/h2")).getText();
		System.out.println(x);
	}

}
