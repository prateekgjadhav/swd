package prac;
import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test44 
{
	public static void main(String[] args) throws InterruptedException 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a word");
		String x=sc.nextLine();
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.google.co.in");
		Thread.sleep(5000);
		//Search a word
		driver.findElement(By.name("q")).sendKeys(x);
		driver.findElement(By.name("btnG")).click();
		Thread.sleep(5000);
		int pcount=1;
		try{
			while(driver.findElement(By.xpath("//*[text()='Next']")).isDisplayed())
			{
				driver.findElement(By.xpath("//*[text()='Next']")).click();
				Thread.sleep(2000);
				pcount=pcount+1;
			}
		}
		catch(Exception e)
		{
			System.out.println("Pagination completed");
		}
		System.out.println("Page count is "+pcount);
		driver.close();
	}

}




