package prac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Test14 
{
	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.flipkart.com");
		Thread.sleep(5000);
		WebElement e=driver.findElement(By.xpath("/html/body/div/div/div/header/div[1]/div/ul/li[5]/a/span[1]"));
		Actions a=new Actions(driver);
		a.moveToElement(e).build().perform();
	}

}
