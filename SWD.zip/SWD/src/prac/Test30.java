package prac;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test30
{
	public static void main(String[] args) 
	{
		//FirefoxDriver driver=new FirefoxDriver();
		//driver.get("http://www.google.co.in");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.google.co.in");
	}
}




