package prac;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class Test58 
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter order number");
		String a=sc.nextLine();
		System.out.println("Enter customer name");
		String b=sc.nextLine();
		System.out.println("Enter departure date");
		String c=sc.nextLine();
		System.out.println("Enter flight number");
		String d=sc.nextLine();
		System.out.println("Enter tickets");
		String e=sc.nextLine();
		System.out.println("Enter class");
		String f=sc.nextLine();
		System.out.println("Enter agent");
		String g=sc.nextLine();
		System.out.println("Enter signature");
		String h=sc.nextLine();
		//connect to DB
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("Jdbc:Odbc:kalam");
		//Perform insert
		Statement st=con.createStatement();
		st.executeUpdate("insert into orders values("+a+",'"+b+"','"+c+"',"+d+","+e+",'"+f+"','"+g+"','"+h+"')");
		//select data into resultset
		ResultSet rs=st.executeQuery("select * from orders");
		int count=0;
		while(rs.next())
		{
			String x=rs.getString(1);//1 is order_number col
			if(x.equals(a))
			{
				count=count+1;
			}
		}
		if(count==0)
		{
			System.out.println("Record was not inserted");
		}
		else if(count==1)
		{
			System.out.println("Record successfully inserted");
		}
		else
		{
			System.out.println("Duplicate was generated");
		}
		//disconnect from DB
		con.close();
	}
}





