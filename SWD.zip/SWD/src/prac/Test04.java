package prac;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test04 
{
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.google.co.in");
		Thread.sleep(5000);
		//Get page screen shot
		File ss=((TakesScreenshot)driver)
				.getScreenshotAs(OutputType.FILE);
		File d1=new File("E:\\batch226\\mindq1.png");
		FileUtils.copyFile(ss,d1);
		Thread.sleep(5000);
		//Get element screen shot
		File es=((FirefoxDriver)driver)
				.findElement(By.name("q"))
				.getScreenshotAs(OutputType.FILE);                
		File d2=new File("E:\\batch226\\mindq2.png");
		FileUtils.copyFile(es,d2);
		driver.close();
	}
}





