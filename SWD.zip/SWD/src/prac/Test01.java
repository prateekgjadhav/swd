package prac;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Test01 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		System.setProperty("webdriver.geckodriver.firefox","C:\\Desktop\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("http://newtours.demoaut.com");
		Thread.sleep(5000);//java
		//Click register
		driver.findElement(By.linkText("REGISTER"))
		                                  .click();
		Thread.sleep(5000);//java
		//Fill fields
		driver.findElement(By.name("firstName"))
		                      .sendKeys("subbarao");
		driver.findElement(By.name("lastName"))
		                           .sendKeys("jessy");
		driver.findElement(By.name("phone"))
							.sendKeys("9000000500");
		driver.findElement(By.name("userName"))
					   .sendKeys("jessy@subbarao.com");
		driver.findElement(By.name("address1"))
		                         .sendKeys("tajmahal");
		driver.findElement(By.name("address2"))
									.sendKeys("office");
		driver.findElement(By.name("city"))
								.sendKeys("banglore");
		driver.findElement(By.name("state"))
								.sendKeys("karnataka");
		driver.findElement(By.name("postalCode"))
								.sendKeys("754568");
		//automate drop-down
		Select s=new 
		  Select(driver.findElement(By.name("country")));
		s.selectByVisibleText("INDIA");
		//Fill further fields
		driver.findElement(By.name("email"))
		                .sendKeys("subbujessies");
		driver.findElement(By.name("password"))
		                       .sendKeys("jessy");
		driver.findElement(By.name("confirmPassword"))
		                       .sendKeys("jessy");
		driver.findElement(By.name("register")).click();
		Thread.sleep(5000);
		//Close site
		driver.close();
	}
}






