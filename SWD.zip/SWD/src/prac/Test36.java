package prac;

public class Test36 
{
	public static void main(String[] args) 
	{
		Test35 obj1=new Test35();
		Test34 obj2=new Test35();
		obj1.add();
		obj1.substract();
		obj1.multiply();
		obj1.divison();
		obj2.add();
		obj2.substract();
		obj2.multiply();
		obj2.divison();

	}

}
