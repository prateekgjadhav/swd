package prac;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test24 
{
	public static void main(String[] args) throws AWTException, InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);       
		//Do login
		driver.findElement(By.name("Email")).sendKeys("s.jagadish100");
		driver.findElement(By.id("next")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.name("Passwd")).sendKeys("9700665505");
		driver.findElement(By.id("signIn")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Click compose
		driver.findElement(By.xpath("//*[text()='COMPOSE']")).click();  
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Fill fields
		driver.findElement(By.xpath("//*[@aria-label='To']")).sendKeys("spsoft.g@gmail.com");
		driver.findElement(By.xpath("//*[@placeholder='Subject']")).sendKeys("kabali");
		driver.findElement(By.xpath("(//*[@aria-label='Message Body'])[2]")).sendKeys("Hi",Keys.ENTER,"kabali on 22nd",Keys.ENTER,"bye");
		driver.findElement(By.xpath("//*[@data-tooltip='Attach files']/div/div/div")).click();
		//Handle file upload pop-up window using Robot
		Thread.sleep(5000);
		StringSelection s=new StringSelection("C:\\Users\\Public\\Pictures\\Sample Pictures\\tulips.jpg");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);    
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(5000);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER); 
		Thread.sleep(15000);
		//Send mail
		driver.findElement(By.xpath("//*[text()='Send']")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Do logout
		driver.findElement(By.xpath("//*[starts-with(@title,'Google Account:')]/span")).click();
		driver.findElement(By.linkText("Sign out")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Close site
		driver.close();
	}
}











