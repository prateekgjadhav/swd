package prac;
public class Child extends Parent
{
	int b; //data member
	Child() //constructor
	{
		b=20;
	}
	void child_disply() //general method
	{
		System.out.println(b);
	}
}

