package prac;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test42 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.mercurytravels.co.in");
		Thread.sleep(5000);
		//Get all input tag elements in page
		List<WebElement> l=driver.findElements(By.tagName("input"));
		for(int i=0;i<l.size();i++)
		{
			String x=l.get(i).getAttribute("type");
			if(x.equals("text"))
			{
				JavascriptExecutor js=(JavascriptExecutor) driver;
				js.executeScript("arguments[0].style.border='2px dotted blue';",l.get(i));
				Thread.sleep(2000);
			}
		}
		//Close site
		driver.close();
	}
}
