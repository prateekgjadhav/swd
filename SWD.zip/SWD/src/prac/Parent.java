package prac;
public class Parent
{
	int a; //data member or property
	Parent() //constructor
	{
		a=10;
	}
	void parent_disply() //general method
	{
		System.out.println(a);
	}
}


