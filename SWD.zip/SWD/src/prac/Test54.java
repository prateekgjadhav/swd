package prac;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class Test54 
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter address");
		String input=sc.nextLine();
		URL u=new URL("http://maps.googleapis.com/maps/api/geocode/json?address="+input+"&sensor=true");
		HttpURLConnection con=(HttpURLConnection)u.openConnection();
		InputStreamReader i=new InputStreamReader(con.getInputStream());
		BufferedReader br=new BufferedReader(i);
		String output=br.readLine(); //read first line
		while(output!=null) 
		{
			System.out.println(output);
			output=br.readLine(); //read next line
		}
		con.disconnect(); //disconnect from service
	}

}
