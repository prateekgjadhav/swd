package prac;
import java.awt.AWTException;
import java.awt.Robot;

import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test25 
{
	public static void main(String[] args) throws AWTException, InterruptedException 
	{
		//Launch selenium-hq site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.seleniumhq.org");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);      
		//Click download 
		driver.findElement(By.linkText("Download")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Click a software download link
		driver.findElement(By.xpath("//*[@id='mainContent']/p[3]/a")).click();
		//Handle file download pop-up window
		Thread.sleep(5000);
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_LEFT);
		r.keyRelease(KeyEvent.VK_LEFT);
		Thread.sleep(5000);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(15000);
		//Close site
		driver.close();
		
	}

}




