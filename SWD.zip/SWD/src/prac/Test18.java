package prac;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test18 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://semantic-ui.com/collections/form.html");
		Thread.sleep(5000);
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("alert('Site opened');");
	}

}





