package prac;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Test12 
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.seleniumhq.org");
		Thread.sleep(5000);
		Actions a=new Actions(driver);
		WebElement  e=driver.findElement(By.linkText("Download"));
		a.moveToElement(e).contextClick().build().perform();
		Thread.sleep(5000);
		a.sendKeys(Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys(Keys.DOWN).build().perform();
		Thread.sleep(5000);
		a.sendKeys(Keys.ENTER).build().perform();           
		Thread.sleep(5000);
		ArrayList al=new ArrayList(driver.getWindowHandles());
		driver.switchTo().window((String) al.get(1));
		driver.close();
		driver.switchTo().window((String) al.get(0));
	}

}






