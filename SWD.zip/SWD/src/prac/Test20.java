package prac;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.safari.SafariDriver;
public class Test20 
{
	public static void main(String[] args)
	{
		System.setProperty("webdriver.geckodriver.firefox","C:\\Desktop\\geckodriver.exe");
		WebDriver driver=new SafariDriver();
		driver.get("http://www.google.co.in");              
	}
}










