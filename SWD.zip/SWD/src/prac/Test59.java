package prac;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class Test59 
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter order number");
		String a=sc.nextLine();
		//connect to DB
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection(
										"Jdbc:Odbc:kalam");
		//Perform deletion
		Statement st=con.createStatement();
		st.executeUpdate("delete from orders where order_number="+a);
		//select data into resultset
		ResultSet rs=st.executeQuery("select * from orders");
		int count=0;
		while(rs.next())
		{
			String x=rs.getString(1);
			if(x.equals(a))
			{
				count=count+1;
			}
		}
		if(count==0)
		{
			System.out.println("Record was deleted successfully");
		}
		else
		{
			System.out.println("record was not deleted");
		}
		//disconnect from DB
		con.close();
	}
}
