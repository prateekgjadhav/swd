package prac;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test06
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.mercurytravels.co.in");
		Thread.sleep(5000);
		//Count of links
		List<WebElement> l=driver.findElements(By.tagName("a"));        
		System.out.println(l.size());
		//count of push-buttons
		List<WebElement> p=driver.findElements(By.xpath("//input[@type='button']"));
		System.out.println(p.size());
		//close site
		driver.close();
	}
}






