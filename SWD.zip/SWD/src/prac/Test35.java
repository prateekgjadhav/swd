package prac;
public class Test35 extends Test34
{
	public int substract() 
	{
		int z;
		z=x-y;
		return(z);
	}
	public int multiply() 
	{
		int z;
		z=x*y;
		return(z);
	}
}
