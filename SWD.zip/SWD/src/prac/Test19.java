package prac;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test19 
{
	public static void main(String[] args) throws InterruptedException 
	{
		//Launch site
		WebDriver driver=new FirefoxDriver();
		driver.get("http://newtours.demoaut.com");
		Thread.sleep(5000);//java
		JavascriptExecutor js=(JavascriptExecutor) driver;
		WebElement e=driver.findElement(By.name("userName"));
		js.executeScript("arguments[0].style.border='4px ridge pink';",e);                
	}
}





