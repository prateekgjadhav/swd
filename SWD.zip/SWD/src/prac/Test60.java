package prac;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test60 
{
	public static void main(String[] args) throws InterruptedException 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter required day, month and year");
		String d=sc.nextLine();
		String m=sc.nextLine();
		String y=sc.nextLine();
		WebDriver driver=new FirefoxDriver();
		driver.get("http://jqueryui.com/datepicker/"); 
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.switchTo().frame(0);  
		Thread.sleep(5000); 
		//Click on textbox so that datepicker will come  
		driver.findElement(By.id("datepicker")).click();  
		Thread.sleep(5000);  
		//Click on next for required month
		String a=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
		String b=driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
		if(Integer.parseInt(b)< Integer.parseInt(y))
		{
			while(2>1)
			{
				a=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
				b=driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
				if(a.equalsIgnoreCase(m) && b.equalsIgnoreCase(y))
				{
					break;
				}
				driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();	
			}
		}
		else if(Integer.parseInt(b)> Integer.parseInt(y))
		{
			while(2>1)
			{
				a=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
				b=driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
				if(a.equalsIgnoreCase(m) && b.equalsIgnoreCase(y))
				{
					break;
				}
				driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
			}
		}
		else
		{
			while(2>1)
			{
				a=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
				if(a.equalsIgnoreCase("january"))
				{
					break;
				}
				driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
			}
			while(2>1)
			{
				a=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
				if(a.equalsIgnoreCase(m))
				{
					break;
				}
				driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();	
			}
		}
		//DatePicker is a table.So navigate to each cell to select required
		driver.findElement(By.linkText(d)).click();
		Thread.sleep(5000);
		driver.close();

	}

}
