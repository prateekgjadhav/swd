package prac;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Test09 
{
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("http://www.gmail.com");
		Thread.sleep(5000);
		driver.findElement(By.name("Email")).sendKeys("s.jagadish100");
		driver.findElement(By.name("signIn")).click();
		Thread.sleep(5000);
		if(driver.findElement(By.name("Passwd"))
				                    .isDisplayed())        
		{
			System.out.println("Userid is valid");
		}
		else
		{
			System.out.println("Userid is invalid");
		}
		driver.close();
	}
}






