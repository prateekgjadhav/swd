package prac;
public class Test29 
{
	public static void main(String[] args) 
	{
		Parent obj1=new Parent();
		obj1.parent_disply();
		Child obj2=new Child();
		obj2.parent_disply();
		obj2.child_disply();
		//Child obj3=new Parent();
		//Parent obj4=new Child();
	}
}




